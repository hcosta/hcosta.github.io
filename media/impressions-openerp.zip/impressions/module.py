# -*- coding: utf-8 -*-
from osv import osv, fields
from types import *
class impression(osv.osv):	

	def getUser(num):
		return 'xxxyyyzzz'	

	_name = "impressions.impression"
	_description = "Taula amb informació de les impressions"
	_columns = {
		'id_impression': fields.integer('Id impressió', required=True, readonly=True),
		'username': fields.char('Usuari',size=256, required=True, readonly=True),
		'printername': fields.char('Impressora',size=256, required=True, readonly=True),
		'jobsize': fields.integer('Pàgines', required=True, readonly=True),
		'title': fields.char('Document',size=256, required=True, readonly=True),
		'jobdate': fields.datetime('Data', required=True, readonly=True),
	}

	_order = 'jobdate desc' 

	_sql_constraints = [
		('id_impression_unique', 'unique(id_impression)', 'La impressió és única'),
	]

impression()

