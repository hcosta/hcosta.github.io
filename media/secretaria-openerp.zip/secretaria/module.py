# -*- coding: utf-8 -*-
from osv import osv, fields
from types import *

""" CLASSE ESTUDIANT """

class estudiant(osv.osv):

	def onchange_poblacio(self, cr, uid, ids, poblacio):
		val = {'codi_postal':'',}
		if poblacio:
			cr.execute('SELECT codi_postal FROM secretaria_poblacio where poblacio = \'%s\'' % poblacio)
			codi_postal = cr.fetchone()[0]

			if codi_postal is None :
				val = {'codi_postal':'',}

			else : val = {'codi_postal':codi_postal,}

		return {'value':val}

	def onchange_dni(self, cr, uid, ids, dni, year):
		
		# Comencem definint dos booleans que indicaran si el dni ja existeix
		# i si estem editant un registre, necessari perquè es tracta igual
		# el formulari de registre que el de edició, i per tant, per defecte
		# es farien avisos de DNI duplicat moltes vegades

		dniTrobat = False
		modeEdicio = False

		# El missatge per defecte és que tot està correcte, no hauria d'apareixer mai
		warning = {
		'title': 'ok',
		'message': 'Tot bé ',
		}
	
		# Diccionari amb els valors del formulari, mirarem si hi ha l'any per 
		# saber si el formulari està buit o s'està editant un registre
		val = {'dni':dni, 'any':year}

		# Probem
		try:	
			# Si exiteix un curs, aleshores estem en mode edició
			if year:
				modeEdicio = True
			
			# Seguidament comprovem si s'ha de autocompletar el DNI
			nif="TRWAGMYFPDXBNJZSQVHLCKE"
			if len(dni) == 8 and dni[0].isdigit() and dni[7].isdigit() :
				val = {'dni':dni+nif[int(dni)%23], 'any':year}
				dni = dni+nif[int(dni)%23]

			# Per últim comprovem si aquest DNI ja existeix			
			cr.execute('SELECT dni FROM secretaria_estudiant where dni = \'%s\'' % dni)
			
			# Si existeix ( s'ha trobat un registre) canviem dniTrobat a Cert
			if cr.fetchone()[0] is not None:
				dniTrobat = True

		# Si peta en algún lloc o posem al warning
		except:

			warning = {
			'title': 'unknown',
			'message': 'Error desconegut',
			}

		# Finalment, peti o no peti, s'executaràn els returns. Retornarem el diccionari depenent de...
		finally :

			# Si s'ha trobat el DNI i estem en mode creació, retornem també el warning.
			if dniTrobat == True and modeEdicio == False:
				warning = {
				'title': 'dni',
				'message': 'Compte, aquest DNI ja està registrat',
				}
				return {'value':val, 'warning': warning}

			# En mode edició o si no es troba el DNI no avisem (evitar spam), 
			# petarà igualment si s'introdueix un DNI duplicat al editar
			else: 
				return {'value':val}

	def _get_poblacio(self, cr, user_id, context=None):

		cr.execute('SELECT poblacio FROM secretaria_poblacio group by poblacio order by poblacio')
		t = ()
		for poblacio in cr.fetchall():  
			t = t + ((poblacio[0], poblacio[0]),) 

		return t
	
	def _get_estudis(self, cr, user_id, context=None):

		cr.execute('SELECT estudis FROM secretaria_estudi')

		t = ()

		for estudi in cr.fetchall():  
			t = t + ((estudi[0], estudi[0]),) 

		return t

	def _omple_expedient_auto(self, cr, uid, ids, context = None):
		cr.execute('SELECT max(numero_expedient) FROM secretaria_estudiant')
		last = cr.fetchone()[0]
		if last is None :
			return 1
		else : return last + 1

	def omple_codi_boto(self, cr, uid, ids, context = None):
		self.write(cr, uid, ids, {'numero_expedient': ' '}, context = context)
		cr.execute('SELECT max(numero_expedient) FROM secretaria_estudiant')
		last = cr.fetchone()[0]
		if last.isdigit() :
			self.write(cr, uid, ids, {'numero_expedient': str(int(last) + 1)}, context = context)
		else : 
			self.write(cr, uid, ids, {'numero_expedient': '1'}, context = context)
		return True


	_name = "secretaria.estudiant"
	_description = "Taula amb les dades dels estudiants"
	_columns = {
		'numero_expedient':fields.integer('Expedient',size=20, required=True, readonly=True),
		'any':fields.char('Any',size=20),
		'nom':fields.char('Nom',size=100),
		'cognoms':fields.char('Cognoms',size=150),
		'estudis':fields.char('Estudis',size=150),
		'dni':fields.char('DNI',size=20),
		'direccio': fields.char('Direcció',size=150),
		'codi_postal': fields.char('Codi postal',size=5),
		'poblacio': fields.selection(_get_poblacio,'Població',size=200),
		'telefon': fields.integer('Telèfon', size=20),
		'anotacions': fields.text('Anotacions'),

	}

	_order = 'id desc' 

	_sql_constraints = [
		('numero_expedient_unique', 'unique(numero_expedient)', 'El número d\'expedient és únic'),
		('dni_unique', 'unique(dni)', 'El DNI és únic'),
	]

	_defaults = {
        	 'numero_expedient':_omple_expedient_auto,
    	}


estudiant()



""" CLASSE POBLACIONS """

class poblacio(osv.osv):	

	_name = "secretaria.poblacio"
	_description = "Taula amb les dades de les poblacions"
	_columns = {
		'codi_postal':fields.char('Codi postal',size=5),
		'poblacio':fields.char('Població',size=200),
	}

	_order = 'poblacio asc' 

poblacio()



""" CLASSE ESTUDIS 

class estudi(osv.osv):

	_name = "secretaria.estudi"
	_description = "Taula amb les dades dels estudis"
	_columns = {
		'estudis':fields.char('Estudis',size=150),
	}

estudi() """
