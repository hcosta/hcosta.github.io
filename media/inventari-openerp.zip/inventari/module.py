# -*- coding: utf-8 -*-
from osv import osv, fields
from types import *

""" CLASSE ESTUDIANT """

class tipus_equip(osv.osv):
  _name = "inventari.tipus_equip"
  _description = "Llista ambs els tipus d'equip"
  _columns = {
    'name':fields.char('Tipus d\'equip',size=200),
  }
  _sql_constraints = [
    ('name', 'unique(name)', 'El tipus d\'equip ha de ser únic'),
  ]
  _order = 'id desc' 


class equip(osv.osv):
  _name = "inventari.equip"
  _description = "Model dels equips que formen l'inventari"
  _columns = {
    'name':fields.char('Número de sèrie',size=50),
    'mac':fields.char('MAC',size=100),
    'pn':fields.char('P.N.',size=50),   
    'tipus_equip':fields.many2one(
        'inventari.tipus_equip',
        'Tipus d\'equip'),
    'model':fields.char('Model',size=150),
    'data_adquisicio':fields.date('Data d\'adquisició'),
    'descripcio':fields.text('Descripció'),
    'origen':fields.char('Origen',size=150),
    'desti':fields.char('Destí',size=150), 
    # 'unitats':fields.char('Unitats',size=50), 
  }
  _order = 'id desc'
  _sql_constraints = [
    ('name_unique', 'unique(name)', 'El número de sèrie ha de ser únic'),
    ('mac', 'unique(mac)', 'La MAC ha de ser única'),
  ]

class incidencia(osv.osv):
  _name = "inventari.incidencia"
  _description = "Model de les incidències associades a cada equip"
  _columns = {
    'name':fields.char('Ticket de la incidència',size=200),
    'equip':fields.many2one(
        'inventari.equip',
        'Equip'),
    'data':fields.date('Data incidència'),
    'descripcio':fields.text('Descripció'),
    'solucionada':fields.boolean('Solucionada')
  }
  _order = 'id desc'
  _defaults = {
    'solucionada':False,
  }
tipus_equip()
equip()
incidencia()


""" CLASSE POBLACIONS

class poblacio(osv.osv):	

	_name = "secretaria.poblacio"
	_description = "Taula amb les dades de les poblacions"
	_columns = {
		'codi_postal':fields.char('Codi postal',size=5),
		'poblacio':fields.char('Població',size=200),
	}

	_order = 'poblacio asc' 

poblacio() 
  
'commercial': 
	_name = "secretaria.estudiant"
	_description = "Taula amb les dades dels estudiants"
	_columns = {
		'numero_expedient':fields.integer('Expedient',size=20, required=True, readonly=True),
		'any':fields.char('Any',size=20),
		'nom':fields.char('Nom',size=100),
		'cognoms':fields.char('Cognoms',size=150),
		'estudis':fields.char('Estudis',size=150),
		'dni':fields.char('DNI',size=20),
		'direccio': fields.char('Direcció',size=150),
		'codi_postal': fields.char('Codi postal',size=5),
		'poblacio': fields.selection(_get_poblacio,'Població'),
		'telefon': fields.integer('Telèfon', size=20),
		'anotacions': fields.text('Anotacions'),

	}

	_order = 'id desc' 

	_sql_constraints = [
		('numero_expedient_unique', 'unique(numero_expedient', 'El número d\'expedient és únic'),
	]

	_defaults = {
        	 'numero_expedient':_omple_expedient_auto,
    	}"""
    	

""" CLASSE ESTUDIS 

class estudi(osv.osv):

	_name = "secretaria.estudi"
	_description = "Taula amb les dades dels estudis"
	_columns = {
		'estudis':fields.char('Estudis',size=150),
	}

estudi() 

    def onchange_poblacio(self, cr, uid, ids, poblacio):

		val = {'codi_postal':'','poblacio':unicode(poblacio, 'utf8')}

		if poblacio:

			cr.execute('SELECT codi_postal FROM secretaria_poblacio where poblacio = \'%s\'' % poblacio)
			codi_postal = cr.fetchone()[0]

			if codi_postal is None :
				val = {'codi_postal':'','poblacio':unicode(poblacio, 'utf8')}
			else : val = {'codi_postal':codi_postal,'poblacio':unicode(poblacio, 'utf8')}

		return {'value':val}


	def _get_poblacio(self, cr, user_id, context=None):

		cr.execute('SELECT poblacio FROM secretaria_poblacio group by poblacio order by poblacio')

		t = ()

		for poblacio in cr.fetchall():  
			t = t + ((poblacio[0], poblacio[0]),) 

		return t
		
	
	def _get_estudis(self, cr, user_id, context=None):

		cr.execute('SELECT estudis FROM secretaria_estudi')

		t = ()

		for estudi in cr.fetchall():  
			t = t + ((estudi[0], estudi[0]),) 

		return t

	def _omple_expedient_auto(self, cr, uid, ids, context = None):
		cr.execute('SELECT max(numero_expedient) FROM secretaria_estudiant')
		last = cr.fetchone()[0]
		if last is None :
			return 1
		else : return last + 1

	def omple_codi_boto(self, cr, uid, ids, context = None):
		self.write(cr, uid, ids, {'numero_expedient': ' '}, context = context)
		cr.execute('SELECT max(numero_expedient) FROM secretaria_estudiant')
		last = cr.fetchone()[0]
		if last.isdigit() :
			self.write(cr, uid, ids, {'numero_expedient': str(int(last) + 1)}, context = context)
		else : 
			self.write(cr, uid, ids, {'numero_expedient': '1'}, context = context)
		return True """